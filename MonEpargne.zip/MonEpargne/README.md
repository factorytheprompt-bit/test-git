# Mon Épargne — Projet Android natif (Kotlin)

Application native (pas de WebView) pour suivre une épargne quotidienne
du 18/09/2026 au 01/10/2027 (379 jours, objectif 1 000 FG/jour, soit 379 000 FG).

## Contenu du projet
- `app/src/main/java/com/monepargne/app/`
  - `SplashActivity.kt` — écran de démarrage avec logo
  - `MainActivity.kt` — écran principal (statistiques, calendrier, dialogues)
  - `DataManager.kt` — stockage local persistant (SharedPreferences + JSON), hors-ligne, sans permission
  - `CalendarAdapter.kt` / `CalendarModels.kt` — calendrier en grille (RecyclerView 7 colonnes)
- `app/src/main/res/` — layouts, couleurs, textes, icônes (icône tirelire, icône adaptative Android 8+)
- Gradle configuré : minSdk 23, targetSdk/compileSdk 34, Kotlin, desugaring pour java.time

## Compilation en APK

### Option A — Android Studio (recommandé, le plus simple)
1. Installer Android Studio (gratuit) : https://developer.android.com/studio
2. Ouvrir le dossier `MonEpargne` avec "Open" (Android Studio régénère automatiquement
   le wrapper Gradle manquant et télécharge les dépendances — connexion internet nécessaire
   la première fois).
3. Attendre la fin de la synchronisation Gradle (barre en bas).
4. Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Cliquer sur "locate" dans la notification, ou voir directement :
   `app/build/outputs/apk/debug/app-debug.apk`

### Option B — Ligne de commande (si Gradle est déjà installé sur votre machine)
```bash
cd MonEpargne
gradle wrapper --gradle-version 8.4      # génère gradlew/gradlew.bat une seule fois
./gradlew assembleDebug                  # Linux/Mac
gradlew.bat assembleDebug                # Windows
```
L'APK compilé (debug, installable directement) se trouve alors à :
```
app/build/outputs/apk/debug/app-debug.apk
```

Pour une version release non signée (à signer avant publication) :
```bash
./gradlew assembleRelease
```
→ `app/build/outputs/apk/release/app-release-unsigned.apk`

## Installer l'APK sur un Samsung Galaxy A16
1. Copier `app-debug.apk` sur le téléphone (câble USB, e-mail à soi-même, Google Drive,
   Bluetooth, etc.).
2. Sur le téléphone, ouvrir l'application **Mes fichiers** et localiser l'APK
   (dossier Téléchargements en général).
3. Appuyer sur le fichier APK. Si Android demande d'autoriser "Installer des applications
   inconnues" pour l'application utilisée (Mes fichiers, Chrome, Gmail...), activer cette
   autorisation dans la boîte de dialogue proposée (Paramètres > Applications >
   Accès spécial > Installer des applications inconnues).
4. Confirmer l'installation, puis ouvrir "Mon Épargne" depuis le tiroir d'applications.

## Notes importantes
- Aucune connexion internet n'est nécessaire pour utiliser l'application : toutes les
  données sont stockées localement sur l'appareil (SharedPreferences), et sont conservées
  après fermeture ou redémarrage du téléphone.
- Aucune permission Android n'est demandée.
- L'icône fournie (tirelire stylisée verte) est un point de départ simple ; vous pouvez la
  remplacer facilement en régénérant les icônes via **clic droit sur `app` > New > Image
  Asset** dans Android Studio, en gardant les mêmes noms de fichiers
  (`ic_launcher`, `ic_launcher_round`, `ic_launcher_foreground`, `ic_launcher_background`).
