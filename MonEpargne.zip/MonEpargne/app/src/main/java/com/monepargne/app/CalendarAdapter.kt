package com.monepargne.app

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

class CalendarAdapter(
    private var items: List<CalendarItem>,
    private val onDayClick: (CalendarItem.Day) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        const val TYPE_HEADER = 0
        const val TYPE_DAY = 1
        const val TYPE_EMPTY = 2
    }

    class HeaderVH(itemView: android.view.View) : RecyclerView.ViewHolder(itemView) {
        val label: TextView = itemView.findViewById(R.id.monthHeaderText)
    }

    class DayVH(itemView: android.view.View) : RecyclerView.ViewHolder(itemView) {
        val dayText: TextView = itemView.findViewById(R.id.dayText)
    }

    class EmptyVH(itemView: android.view.View) : RecyclerView.ViewHolder(itemView)

    override fun getItemViewType(position: Int): Int = when (items[position]) {
        is CalendarItem.MonthHeader -> TYPE_HEADER
        is CalendarItem.Day -> TYPE_DAY
        is CalendarItem.Empty -> TYPE_EMPTY
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return when (viewType) {
            TYPE_HEADER -> HeaderVH(inflater.inflate(R.layout.item_month_header, parent, false))
            TYPE_DAY -> DayVH(inflater.inflate(R.layout.item_day, parent, false))
            else -> EmptyVH(inflater.inflate(R.layout.item_empty, parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val item = items[position]) {
            is CalendarItem.MonthHeader -> {
                (holder as HeaderVH).label.text = item.label
            }
            is CalendarItem.Day -> {
                val h = holder as DayVH
                h.dayText.text = item.dayOfMonth.toString()
                val context = h.itemView.context
                when {
                    item.hasDeposit -> {
                        h.itemView.setBackgroundResource(R.drawable.bg_day_deposit)
                        h.dayText.setTextColor(ContextCompat.getColor(context, R.color.white))
                    }
                    item.isToday -> {
                        h.itemView.setBackgroundResource(R.drawable.bg_day_today)
                        h.dayText.setTextColor(ContextCompat.getColor(context, R.color.text_primary))
                    }
                    else -> {
                        h.itemView.setBackgroundResource(R.drawable.bg_day_default)
                        h.dayText.setTextColor(ContextCompat.getColor(context, R.color.text_primary))
                    }
                }
                h.itemView.setOnClickListener { onDayClick(item) }
            }
            is CalendarItem.Empty -> { /* cellule vide pour aligner le premier jour du mois */ }
        }
    }

    override fun getItemCount(): Int = items.size

    fun updateItems(newItems: List<CalendarItem>) {
        items = newItems
        notifyDataSetChanged()
    }
}
