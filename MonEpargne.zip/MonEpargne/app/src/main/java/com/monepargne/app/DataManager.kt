package com.monepargne.app

import android.content.Context
import org.json.JSONObject

/**
 * Gère le stockage local des dépôts d'épargne via SharedPreferences.
 * Les données persistent après fermeture / redémarrage de l'application
 * et ne nécessitent aucune connexion réseau ni compte utilisateur.
 */
class DataManager(context: Context) {

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS_NAME = "mon_epargne_prefs"
        private const val KEY_DEPOSITS = "deposits"
    }

    /** Retourne toutes les entrées: date (yyyy-MM-dd) -> montant en FG */
    fun getAllDeposits(): MutableMap<String, Long> {
        val json = prefs.getString(KEY_DEPOSITS, "{}") ?: "{}"
        val obj = JSONObject(json)
        val map = mutableMapOf<String, Long>()
        val keys = obj.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            map[key] = obj.getLong(key)
        }
        return map
    }

    fun getDeposit(date: String): Long? = getAllDeposits()[date]

    fun setDeposit(date: String, amount: Long) {
        val map = getAllDeposits()
        map[date] = amount
        saveAll(map)
    }

    fun removeDeposit(date: String) {
        val map = getAllDeposits()
        map.remove(date)
        saveAll(map)
    }

    fun resetAll() {
        prefs.edit().remove(KEY_DEPOSITS).apply()
    }

    private fun saveAll(map: Map<String, Long>) {
        val obj = JSONObject()
        map.forEach { (k, v) -> obj.put(k, v) }
        prefs.edit().putString(KEY_DEPOSITS, obj.toString()).apply()
    }
}
