package com.monepargne.app

/** Représente un élément affiché dans le calendrier (RecyclerView en grille de 7 colonnes). */
sealed class CalendarItem {
    data class MonthHeader(val label: String) : CalendarItem()
    data class Day(
        val date: String,       // format yyyy-MM-dd, clé de stockage
        val dayOfMonth: Int,
        val hasDeposit: Boolean,
        val isToday: Boolean
    ) : CalendarItem()
    object Empty : CalendarItem()
}
