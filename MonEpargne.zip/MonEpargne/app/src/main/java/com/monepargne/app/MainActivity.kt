package com.monepargne.app

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.text.NumberFormat
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.TextStyle
import java.time.temporal.ChronoUnit
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var dataManager: DataManager
    private lateinit var adapter: CalendarAdapter
    private lateinit var recyclerView: RecyclerView

    private lateinit var totalText: TextView
    private lateinit var daysCountText: TextView
    private lateinit var averageText: TextView
    private lateinit var goalText: TextView
    private lateinit var progressText: TextView
    private lateinit var progressBar: ProgressBar

    // Période fixe de l'épargne : 18/09/2026 -> 01/10/2027
    private val startDate: LocalDate = LocalDate.of(2026, 9, 18)
    private val endDate: LocalDate = LocalDate.of(2027, 10, 1)
    private val totalDays: Int = ChronoUnit.DAYS.between(startDate, endDate).toInt() + 1
    private val goalPerDay = 1000L
    private val totalGoal: Long by lazy { totalDays.toLong() * goalPerDay }

    private val numberFormat: NumberFormat = NumberFormat.getInstance(Locale.FRANCE)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dataManager = DataManager(this)

        totalText = findViewById(R.id.totalText)
        daysCountText = findViewById(R.id.daysCountText)
        averageText = findViewById(R.id.averageText)
        goalText = findViewById(R.id.goalText)
        progressText = findViewById(R.id.progressText)
        progressBar = findViewById(R.id.progressBar)
        recyclerView = findViewById(R.id.calendarRecyclerView)

        goalText.text = getString(R.string.goal_format, numberFormat.format(totalGoal))

        val layoutManager = GridLayoutManager(this, 7)
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                return if (adapter.getItemViewType(position) == CalendarAdapter.TYPE_HEADER) 7 else 1
            }
        }
        recyclerView.layoutManager = layoutManager

        adapter = CalendarAdapter(buildItems()) { day -> showDepositDialog(day.date) }
        recyclerView.adapter = adapter

        findViewById<Button>(R.id.resetButton).setOnClickListener { confirmReset() }
        findViewById<FloatingActionButton>(R.id.addDepositFab).setOnClickListener { showDatePicker() }

        refreshStats()
    }

    /** Construit la liste des éléments du calendrier (en-têtes de mois + jours + cellules vides d'alignement). */
    private fun buildItems(): List<CalendarItem> {
        val deposits = dataManager.getAllDeposits()
        val today = LocalDate.now()
        val items = mutableListOf<CalendarItem>()
        var current = startDate
        var lastMonth = -1

        while (!current.isAfter(endDate)) {
            if (current.monthValue != lastMonth || (current.monthValue == lastMonth && current == startDate)) {
                val monthLabel = current.month.getDisplayName(TextStyle.FULL, Locale.FRENCH)
                    .replaceFirstChar { it.uppercase() } + " " + current.year
                items.add(CalendarItem.MonthHeader(monthLabel))
                lastMonth = current.monthValue

                // Alignement: la semaine commence le lundi (1) et finit le dimanche (7)
                val weekday = current.dayOfWeek.value
                val paddingCount = weekday - 1
                repeat(paddingCount) { items.add(CalendarItem.Empty) }
            }

            val key = current.toString() // format yyyy-MM-dd
            val hasDeposit = deposits.containsKey(key)
            items.add(CalendarItem.Day(key, current.dayOfMonth, hasDeposit, current == today))
            current = current.plusDays(1)
        }
        return items
    }

    private fun refreshStats() {
        val deposits = dataManager.getAllDeposits()
        val total = deposits.values.sum()
        val daysCount = deposits.size
        val average = if (daysCount > 0) total / daysCount else 0L
        val progress = if (totalGoal > 0)
            ((total.toDouble() / totalGoal.toDouble()) * 100).coerceIn(0.0, 100.0)
        else 0.0

        totalText.text = getString(R.string.total_format, numberFormat.format(total))
        daysCountText.text = getString(R.string.days_count_format, daysCount, totalDays)
        averageText.text = getString(R.string.average_format, numberFormat.format(average))
        progressText.text = getString(R.string.progress_format, String.format(Locale.FRANCE, "%.1f", progress))
        progressBar.progress = progress.toInt()
    }

    private fun refreshAll() {
        adapter.updateItems(buildItems())
        refreshStats()
    }

    private fun showDatePicker() {
        val today = LocalDate.now().let {
            when {
                it.isBefore(startDate) -> startDate
                it.isAfter(endDate) -> endDate
                else -> it
            }
        }
        val dialog = DatePickerDialog(this, { _, year, month, dayOfMonth ->
            val picked = LocalDate.of(year, month + 1, dayOfMonth)
            if (picked.isBefore(startDate) || picked.isAfter(endDate)) {
                Toast.makeText(this, R.string.date_out_of_range, Toast.LENGTH_SHORT).show()
            } else {
                showDepositDialog(picked.toString())
            }
        }, today.year, today.monthValue - 1, today.dayOfMonth)

        dialog.datePicker.minDate = startDate.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
        dialog.datePicker.maxDate = endDate.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
        dialog.show()
    }

    /** Ouvre le dialogue permettant de saisir, modifier ou supprimer le dépôt d'une date donnée. */
    private fun showDepositDialog(date: String) {
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_deposit, null)
        val dateLabel = view.findViewById<TextView>(R.id.dialogDateLabel)
        val amountInput = view.findViewById<EditText>(R.id.amountInput)
        val existing = dataManager.getDeposit(date)

        val parsedDate = LocalDate.parse(date)
        val formatted = "${parsedDate.dayOfMonth} " +
            parsedDate.month.getDisplayName(TextStyle.FULL, Locale.FRENCH) + " ${parsedDate.year}"
        dateLabel.text = formatted
        if (existing != null) amountInput.setText(existing.toString())

        view.findViewById<Button>(R.id.quick1000).setOnClickListener { amountInput.setText("1000") }
        view.findViewById<Button>(R.id.quick2000).setOnClickListener { amountInput.setText("2000") }
        view.findViewById<Button>(R.id.quick5000).setOnClickListener { amountInput.setText("5000") }
        view.findViewById<Button>(R.id.quick10000).setOnClickListener { amountInput.setText("10000") }

        val builder = AlertDialog.Builder(this)
            .setView(view)
            .setPositiveButton(R.string.save, null)
            .setNegativeButton(R.string.cancel, null)
        if (existing != null) {
            builder.setNeutralButton(R.string.delete, null)
        }
        val dialog = builder.create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val text = amountInput.text.toString().trim()
                val amount = text.toLongOrNull()
                if (amount == null || amount <= 0) {
                    Toast.makeText(this, R.string.invalid_amount, Toast.LENGTH_SHORT).show()
                } else {
                    dataManager.setDeposit(date, amount)
                    refreshAll()
                    dialog.dismiss()
                }
            }
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL)?.setOnClickListener {
                dataManager.removeDeposit(date)
                refreshAll()
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun confirmReset() {
        AlertDialog.Builder(this)
            .setTitle(R.string.reset_title)
            .setMessage(R.string.reset_message)
            .setPositiveButton(R.string.reset_confirm) { _, _ ->
                dataManager.resetAll()
                refreshAll()
                Toast.makeText(this, R.string.reset_done, Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
}
